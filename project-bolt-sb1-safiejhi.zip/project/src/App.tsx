import { useEffect, useMemo, useState } from 'react';
import {
  ArrowRight,
  ChevronDown,
  Heart,
  Menu,
  Minus,
  Plus,
  Search,
  ShoppingBag,
  Star,
  UserRound,
  X,
} from 'lucide-react';

type Category = 'All' | 'New in' | 'Apparel' | 'Accessories' | 'Home';
type Product = {
  id: number;
  name: string;
  category: Exclude<Category, 'All'>;
  price: number;
  compareAt?: number;
  rating: number;
  reviews: number;
  image: string;
  color: string;
  badge?: string;
};
type CartItem = Product & { quantity: number };
type Overlay = 'cart' | 'account' | 'checkout' | 'menu' | null;

const products: Product[] = [
  { id: 1, name: 'The Essential Tote', category: 'Accessories', price: 88, rating: 4.9, reviews: 42, image: 'https://images.pexels.com/photos/17938771/pexels-photo-17938771.jpeg?auto=compress&cs=tinysrgb&w=900', color: 'Oat', badge: 'Best seller' },
  { id: 2, name: 'Everyday Hoops', category: 'Accessories', price: 54, rating: 4.8, reviews: 31, image: 'https://images.pexels.com/photos/9430439/pexels-photo-9430439.jpeg?auto=compress&cs=tinysrgb&w=900', color: 'Gold' },
  { id: 3, name: 'Cloud Rib Tank', category: 'Apparel', price: 48, rating: 4.7, reviews: 28, image: 'https://images.pexels.com/photos/21839237/pexels-photo-21839237.jpeg?auto=compress&cs=tinysrgb&w=900', color: 'Bone', badge: 'New' },
  { id: 4, name: 'Soft Focus Sunglasses', category: 'Accessories', price: 72, compareAt: 90, rating: 4.6, reviews: 19, image: 'https://images.pexels.com/photos/29274467/pexels-photo-29274467.jpeg?auto=compress&cs=tinysrgb&w=900', color: 'Smoke', badge: 'Sale' },
  { id: 5, name: 'Form Ceramic Vase', category: 'Home', price: 42, rating: 4.9, reviews: 16, image: 'https://images.pexels.com/photos/14723665/pexels-photo-14723665.jpeg?auto=compress&cs=tinysrgb&w=900', color: 'Stone' },
  { id: 6, name: 'The Daily Ring', category: 'Accessories', price: 38, rating: 4.8, reviews: 23, image: 'https://images.pexels.com/photos/9430977/pexels-photo-9430977.jpeg?auto=compress&cs=tinysrgb&w=900', color: 'Silver' },
  { id: 7, name: 'Studio Linen Shirt', category: 'Apparel', price: 96, rating: 4.8, reviews: 14, image: 'https://images.pexels.com/photos/5494386/pexels-photo-5494386.jpeg?auto=compress&cs=tinysrgb&w=900', color: 'Chalk' },
  { id: 8, name: 'Sunday Carryall', category: 'Accessories', price: 110, rating: 5, reviews: 11, image: 'https://images.pexels.com/photos/17938771/pexels-photo-17938771.jpeg?auto=compress&cs=tinysrgb&w=900', color: 'Espresso' },
];

const money = (amount: number) => `$${amount.toFixed(2)}`;

function useStoredState<T>(key: string, initialValue: T) {
  const [value, setValue] = useState<T>(() => {
    try {
      const stored = localStorage.getItem(key);
      return stored ? (JSON.parse(stored) as T) : initialValue;
    } catch {
      return initialValue;
    }
  });

  useEffect(() => localStorage.setItem(key, JSON.stringify(value)), [key, value]);
  return [value, setValue] as const;
}

function App() {
  const [category, setCategory] = useState<Category>('All');
  const [query, setQuery] = useState('');
  const [sort, setSort] = useState('Featured');
  const [cart, setCart] = useStoredState<CartItem[]>('popline-cart', []);
  const [wishlist, setWishlist] = useStoredState<number[]>('popline-wishlist', []);
  const [orders, setOrders] = useStoredState<number>('popline-orders', 0);
  const [overlay, setOverlay] = useState<Overlay>(null);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [promo, setPromo] = useState('');
  const [promoApplied, setPromoApplied] = useState(false);
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const filteredProducts = useMemo(() => {
    const result = products.filter((product) => {
      const matchesCategory = category === 'All' || product.category === category;
      const matchesQuery = product.name.toLowerCase().includes(query.toLowerCase());
      return matchesCategory && matchesQuery;
    });
    if (sort === 'Price: low to high') return [...result].sort((a, b) => a.price - b.price);
    if (sort === 'Price: high to low') return [...result].sort((a, b) => b.price - a.price);
    return result;
  }, [category, query, sort]);

  const cartCount = cart.reduce((total, item) => total + item.quantity, 0);
  const subtotal = cart.reduce((total, item) => total + item.price * item.quantity, 0);
  const discount = promoApplied ? subtotal * 0.15 : 0;
  const shipping = subtotal > 100 || subtotal === 0 ? 0 : 8;
  const total = subtotal - discount + shipping;

  const scrollToShop = () => document.getElementById('shop')?.scrollIntoView({ behavior: 'smooth' });
  const toggleWishlist = (id: number) => setWishlist((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id]);
  const addToCart = (product: Product) => {
    setCart((current) => {
      const existing = current.find((item) => item.id === product.id);
      return existing ? current.map((item) => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item) : [...current, { ...product, quantity: 1 }];
    });
    setOverlay('cart');
  };
  const changeQuantity = (id: number, amount: number) => setCart((current) => current.map((item) => item.id === id ? { ...item, quantity: Math.max(0, item.quantity + amount) } : item).filter((item) => item.quantity > 0));

  return (
    <div className="min-h-screen bg-[#fbfaf8] text-[#171716]">
      <div className="announcement">Complimentary shipping on orders over $100 <ArrowRight size={13} /></div>
      <header className="site-header">
        <button className="mobile-menu" aria-label="Open menu" onClick={() => setOverlay('menu')}><Menu size={21} /></button>
        <nav className="desktop-nav" aria-label="Main navigation"><a href="#shop">Shop</a><a href="#about">About</a><a href="#journal">Journal</a></nav>
        <a className="brand" href="#top"><img src="/logo.png" alt="" /><span>Popline</span></a>
        <div className="header-actions"><button aria-label="Search" onClick={() => document.getElementById('search')?.focus()}><Search size={18} /><span>Search</span></button><button aria-label="Account" onClick={() => setOverlay('account')}><UserRound size={18} /><span>Account</span></button><button aria-label="Shopping bag" onClick={() => setOverlay('cart')}><ShoppingBag size={18} /><span>Bag ({cartCount})</span></button></div>
      </header>

      <main id="top">
        <section className="hero">
          <img src="https://images.pexels.com/photos/9430439/pexels-photo-9430439.jpeg?auto=compress&cs=tinysrgb&w=1800" alt="Jewelry arranged on a warm neutral surface" />
          <div className="hero-overlay" />
          <div className="hero-copy"><p className="eyebrow light">The new everyday</p><h1>Thoughtfully made.<br />Carefully chosen.</h1><p>Pieces with a point of view, made to move through your everyday.</p><button className="button button-light" onClick={scrollToShop}>Explore the collection <ArrowRight size={16} /></button></div>
        </section>

        <section className="intro" id="about"><p className="eyebrow">Popline / 01</p><h2>Good things, made better.</h2><p className="intro-text">We look for the objects that earn their place. Considered materials, clever details, and just enough personality to make the ordinary feel new.</p></section>

        <section className="shop-section" id="shop">
          <div className="section-heading"><div><p className="eyebrow">The edit / 02</p><h2>Shop the latest</h2></div><p className="result-count">{filteredProducts.length} pieces</p></div>
          <div className="shop-controls"><div className="category-tabs">{(['All', 'New in', 'Apparel', 'Accessories', 'Home'] as Category[]).map((item) => <button key={item} className={category === item ? 'active' : ''} onClick={() => setCategory(item)}>{item}</button>)}</div><div className="shop-tools"><label className="search-field"><Search size={16} /><input id="search" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search pieces" /></label><label className="sort-field"><span>Sort</span><select value={sort} onChange={(event) => setSort(event.target.value)}><option>Featured</option><option>Price: low to high</option><option>Price: high to low</option></select><ChevronDown size={15} /></label></div></div>
          <div className="product-grid">{filteredProducts.map((product) => <ProductCard key={product.id} product={product} wished={wishlist.includes(product.id)} onWishlist={() => toggleWishlist(product.id)} onAdd={() => addToCart(product)} onOpen={() => setSelectedProduct(product)} />)}</div>
        </section>

        <section className="feature-banner" id="journal"><div><p className="eyebrow">A little more considered</p><h2>Objects that make<br />the everyday feel special.</h2><button className="text-link" onClick={scrollToShop}>Read our approach <ArrowRight size={16} /></button></div><img src="https://images.pexels.com/photos/14723665/pexels-photo-14723665.jpeg?auto=compress&cs=tinysrgb&w=1100" alt="Minimal still life on a stone surface" /></section>
        <section className="newsletter"><div><p className="eyebrow">Stay in the know</p><h2>Good news, occasionally.</h2></div>{subscribed ? <p className="success-message">You’re on the list. See you in your inbox.</p> : <form onSubmit={(event) => { event.preventDefault(); if (email) setSubscribed(true); }}><input type="email" required value={email} onChange={(event) => setEmail(event.target.value)} placeholder="Your email address" /><button aria-label="Subscribe"><ArrowRight size={18} /></button></form>}</section>
      </main>

      <footer><div className="footer-brand"><a className="brand" href="#top"><img src="/logo.png" alt="" /><span>Popline</span></a><p>Thoughtfully made.<br />Carefully chosen.</p></div><div><p className="footer-label">Explore</p><a href="#shop">Shop all</a><a href="#shop">New in</a><a href="#journal">Our journal</a></div><div><p className="footer-label">Help</p><button onClick={() => setOverlay('account')}>Account</button><button onClick={() => setOverlay('cart')}>Shipping & returns</button><a href="mailto:hello@popline.co">Contact us</a></div><div><p className="footer-label">Follow along</p><div className="socials"><a href="#top">Instagram</a><a href="#top">Pinterest</a></div></div><div className="footer-bottom"><span>© 2026 Popline</span><span>Made for the everyday</span></div></footer>

      {selectedProduct && <ProductModal product={selectedProduct} wished={wishlist.includes(selectedProduct.id)} onClose={() => setSelectedProduct(null)} onWishlist={() => toggleWishlist(selectedProduct.id)} onAdd={() => { addToCart(selectedProduct); setSelectedProduct(null); }} />}
      {overlay === 'cart' && <CartDrawer cart={cart} subtotal={subtotal} discount={discount} shipping={shipping} total={total} promo={promo} promoApplied={promoApplied} setPromo={setPromo} setPromoApplied={setPromoApplied} onClose={() => setOverlay(null)} onChangeQuantity={changeQuantity} onCheckout={() => setOverlay('checkout')} />}
      {overlay === 'checkout' && <CheckoutModal total={total} onClose={() => setOverlay(null)} onBack={() => setOverlay('cart')} onComplete={() => { setOrders((value) => value + 1); setCart([]); setOverlay(null); }} />}
      {overlay === 'account' && <AccountModal orders={orders} onClose={() => setOverlay(null)} />}
      {overlay === 'menu' && <MobileMenu onClose={() => setOverlay(null)} onShop={() => { setOverlay(null); scrollToShop(); }} />}
    </div>
  );
}

function ProductCard({ product, wished, onWishlist, onAdd, onOpen }: { product: Product; wished: boolean; onWishlist: () => void; onAdd: () => void; onOpen: () => void }) {
  return <article className="product-card"><div className="product-image" onClick={onOpen}><img src={product.image} alt={product.name} />{product.badge && <span className="product-badge">{product.badge}</span>}<button className={`wishlist-button ${wished ? 'wished' : ''}`} aria-label="Save to wishlist" onClick={(event) => { event.stopPropagation(); onWishlist(); }}><Heart size={17} fill={wished ? 'currentColor' : 'none'} /></button><button className="quick-add" onClick={(event) => { event.stopPropagation(); onAdd(); }}>Add to bag <Plus size={15} /></button></div><div className="product-info"><div><h3>{product.name}</h3><p>{product.color}</p></div><div className="product-price"><strong>{money(product.price)}</strong>{product.compareAt && <del>{money(product.compareAt)}</del>}</div></div><div className="rating"><Star size={12} fill="currentColor" /> {product.rating} <span>({product.reviews})</span></div></article>;
}

function ProductModal({ product, wished, onClose, onWishlist, onAdd }: { product: Product; wished: boolean; onClose: () => void; onWishlist: () => void; onAdd: () => void }) {
  return <div className="modal-backdrop" onClick={onClose}><div className="product-modal" onClick={(event) => event.stopPropagation()}><button className="close-button" onClick={onClose}><X size={20} /></button><img src={product.image} alt={product.name} /><div className="modal-details"><p className="eyebrow">{product.category}</p><h2>{product.name}</h2><div className="modal-rating"><Star size={14} fill="currentColor" /> {product.rating} <span>{product.reviews} reviews</span></div><p className="modal-price">{money(product.price)} {product.compareAt && <del>{money(product.compareAt)}</del>}</p><p className="modal-copy">A considered essential with a little something extra. Designed for repeat wear, easy gifting, and the places your day takes you.</p><div className="modal-actions"><button className="button button-dark" onClick={onAdd}>Add to bag <ArrowRight size={16} /></button><button className="save-button" onClick={onWishlist}><Heart size={18} fill={wished ? 'currentColor' : 'none'} /> {wished ? 'Saved' : 'Save for later'}</button></div><p className="shipping-note">Complimentary shipping over $100 · Easy returns within 30 days</p></div></div></div>;
}

function CartDrawer({ cart, subtotal, discount, shipping, total, promo, promoApplied, setPromo, setPromoApplied, onClose, onChangeQuantity, onCheckout }: { cart: CartItem[]; subtotal: number; discount: number; shipping: number; total: number; promo: string; promoApplied: boolean; setPromo: (value: string) => void; setPromoApplied: (value: boolean) => void; onClose: () => void; onChangeQuantity: (id: number, amount: number) => void; onCheckout: () => void }) {
  return <div className="drawer-backdrop" onClick={onClose}><aside className="drawer" onClick={(event) => event.stopPropagation()}><div className="drawer-head"><div><p className="eyebrow">Your bag</p><h2>{cart.length ? `${cart.reduce((sum, item) => sum + item.quantity, 0)} pieces` : 'A quiet bag'}</h2></div><button className="close-button" onClick={onClose}><X size={20} /></button></div>{cart.length ? <><div className="cart-items">{cart.map((item) => <div className="cart-item" key={item.id}><img src={item.image} alt={item.name} /><div className="cart-item-info"><h3>{item.name}</h3><p>{item.color} · {money(item.price)}</p><div className="quantity"><button onClick={() => onChangeQuantity(item.id, -1)}><Minus size={13} /></button><span>{item.quantity}</span><button onClick={() => onChangeQuantity(item.id, 1)}><Plus size={13} /></button></div></div></div>)}</div><div className="promo-row"><input value={promo} onChange={(event) => setPromo(event.target.value)} placeholder="Promo code" /><button onClick={() => setPromoApplied(promo.trim().toLowerCase() === 'welcome15')}>{promoApplied ? 'Applied' : 'Apply'}</button></div><div className="summary"><div><span>Subtotal</span><span>{money(subtotal)}</span></div>{promoApplied && <div className="discount"><span>Welcome 15%</span><span>−{money(discount)}</span></div>}<div><span>Shipping</span><span>{shipping ? money(shipping) : 'Complimentary'}</span></div><div className="total"><span>Total</span><strong>{money(total)}</strong></div></div><button className="button button-dark full-width" onClick={onCheckout}>Continue to checkout <ArrowRight size={16} /></button></> : <div className="empty-bag"><ShoppingBag size={28} strokeWidth={1.3} /><p>Your bag is waiting for something good.</p><button className="text-link" onClick={onClose}>Keep browsing <ArrowRight size={16} /></button></div>}</aside></div>;
}

function CheckoutModal({ total, onClose, onBack, onComplete }: { total: number; onClose: () => void; onBack: () => void; onComplete: () => void }) {
  return <div className="modal-backdrop"><div className="checkout-modal"><button className="close-button" onClick={onClose}><X size={20} /></button><p className="eyebrow">Popline checkout</p><h2>Almost yours.</h2><p className="checkout-intro">This demo checkout keeps your details on this device. No payment is processed.</p><form onSubmit={(event) => { event.preventDefault(); onComplete(); }}><div className="form-grid"><label>First name<input required placeholder="Alex" /></label><label>Last name<input required placeholder="Morgan" /></label></div><label>Email address<input required type="email" placeholder="alex@example.com" /></label><label>Address<input required placeholder="123 Somewhere Street" /></label><div className="form-grid"><label>City<input required placeholder="Brooklyn" /></label><label>Postcode<input required placeholder="11211" /></label></div><div className="checkout-total"><span>Order total</span><strong>{money(total)}</strong></div><button className="button button-dark full-width" type="submit">Place demo order <ArrowRight size={16} /></button><button className="back-link" type="button" onClick={onBack}>Back to bag</button></form></div></div>;
}

function AccountModal({ orders, onClose }: { orders: number; onClose: () => void }) {
  const [signedIn, setSignedIn] = useState(false);
  return <div className="modal-backdrop" onClick={onClose}><div className="account-modal" onClick={(event) => event.stopPropagation()}><button className="close-button" onClick={onClose}><X size={20} /></button>{signedIn ? <><p className="eyebrow">Your Popline</p><h2>Welcome back.</h2><p className="modal-copy">Your account is ready for the good stuff.</p><div className="account-stats"><div><strong>{orders}</strong><span>Orders</span></div><div><strong>0</strong><span>Saved addresses</span></div><div><strong>0</strong><span>Wishlists</span></div></div><button className="back-link" onClick={() => setSignedIn(false)}>Sign out</button></> : <><p className="eyebrow">Your Popline</p><h2>Make it yours.</h2><p className="modal-copy">Sign in to keep your wishlist, orders, and details close by.</p><label>Email address<input type="email" placeholder="you@example.com" /></label><label>Password<input type="password" placeholder="••••••••" /></label><button className="button button-dark full-width" onClick={() => setSignedIn(true)}>Sign in <ArrowRight size={16} /></button><button className="back-link" onClick={() => setSignedIn(true)}>Create an account</button></>}</div></div>;
}

function MobileMenu({ onClose, onShop }: { onClose: () => void; onShop: () => void }) {
  return <div className="mobile-menu-panel"><div className="drawer-head"><a className="brand" href="#top"><img src="/logo.png" alt="" /><span>Popline</span></a><button className="close-button" onClick={onClose}><X size={20} /></button></div><nav><button onClick={onShop}>Shop</button><button onClick={() => { onClose(); document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' }); }}>About</button><button onClick={() => { onClose(); document.getElementById('journal')?.scrollIntoView({ behavior: 'smooth' }); }}>Journal</button></nav></div>;
}

export default App;
